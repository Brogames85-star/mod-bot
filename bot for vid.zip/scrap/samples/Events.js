// Simple event handler 

// Pass params in
module.exports = (params) => {

    // Enter code of event 

}