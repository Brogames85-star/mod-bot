module.exports = () => {
    _id: {
        prefix: String
    }
}

