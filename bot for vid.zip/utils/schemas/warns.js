module.exports = () => {
    user_id: {
        _id: {
            warning_id: {
                reason: String
                mod: String
                date: String
        }
    }
    }
}