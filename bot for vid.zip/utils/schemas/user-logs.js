module.exports = () => {
    user_id: {
        _id: {
            log_id: {
                type: String
                mod: String
                date: String
        }
    }
    }
}