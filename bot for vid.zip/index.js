const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`));

const { Client } = require('discord.js');
const client = new Client({
    partials: ['MESSAGE', 'CHANNEL', 'REACTION']
});

client.login(process.env.token)

require('./utils/defines').run(client)
require('./utils/structure/registery').run(client);
require('./utils/handlers/commands')(client);
require('./utils/handlers/events')(client);

client.on('message', (message) => {
    require('./utils/handlers/tags')(client, message)
    require('./utils/handlers/handler')(client, message);
    });

client.on('messageUpdate', (o, message) => {
    require('./utils/handlers/tags')(client, message)
    require('./utils/handlers/handler')(client, message)
});

client.login(process.env.TOKEN).catch(() => {
    console.log('Incorrect token given!! Please make sure to go to the config folder and check all files and fill them out');
});